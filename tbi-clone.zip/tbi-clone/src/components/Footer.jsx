import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-black text-white p-10">
      <div className="container mx-auto grid grid-cols-2 gap-10">
        <div>
          <p className="italic text-lg">"Harnessing the innovative potential of students and alumni to create a better tomorrow."</p>
          <div className="flex space-x-4 mt-4">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"><img src="/insta.jpeg" alt="Instagram" className="h-6 w-6" /></a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"><img src="/linkedin.png" alt="LinkedIn" className="h-6 w-6" /></a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer"><img src="/yt.png" alt="YouTube" className="h-6 w-6" /></a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><img src="/fb.png" alt="Facebook" className="h-6 w-6" /></a>
          </div>
        </div>
        <div>
          <div className="font-bold">Contact us</div>
          <div className="mt-2">
            <div>Email: office.tbi@geu.ac.in</div>
            <div>Email: directortbi@geu.ac.in</div>
            <div>Contact No: +91 72170 56795</div>
            <div>Office Address: TBI-GEU office, 3rd Floor CSIT block, 566/6, Bell Road, Society Area, Clement Town, Dehradun, Bharu Wala Grant, Uttarakhand 248002</div>
          </div>
        </div>
      </div>
      <div className="text-center mt-10">
        © Copyright TBI GEU. All Rights Reserved
        <div>Designed and Developed by TBI GEU Web Team</div>
      </div>
    </footer>
  );
};

export default Footer;
