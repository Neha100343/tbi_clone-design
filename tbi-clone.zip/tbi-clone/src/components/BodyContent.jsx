import React from 'react';

const BodyContent = () => {
  return (
    <div className="main-content">
      <div className="bg-gray-100 py-20 text-center">
        <h2 className="text-4xl font-bold mb-6">Skill Development</h2>
        <p className="text-xl mx-auto max-w-4xl">
          We're dedicated to fostering an environment where individuals can expand their knowledge, hone their skills,
          and grow both personally and professionally.
        </p>
      </div>

      <div className="bg-white py-20">
        <div className="container mx-auto grid grid-cols-2 gap-10 items-center">
          <img src="/people.png" alt="Event Image" className="rounded-lg shadow-xl"/>
          <div>
            <h3 className="text-3xl font-bold mb-6">TBI-GEU Event</h3>
            <p className="text-lg mb-6">
              TBI-GEU is dedicated to supporting students and alumni as they pursue groundbreaking ideas,
              build future-forward ventures, and embrace the learning required for effective innovation.
            </p>
            <button className="bg-red-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-red-700 transition duration-300">
              Learn More
            </button>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 py-20 text-center">
        <h2 className="text-4xl font-bold mb-6">Join Us</h2>
        <p className="text-xl mb-10 mx-auto max-w-4xl">
          Join a diverse team dedicated to nurturing brilliant ideas and connecting visionary leaders and entrepreneurs.
        </p>
        <div className="grid grid-cols-3 gap-10 px-20">
          <div className="bg-white p-8 shadow-lg rounded-lg">
            <h4 className="text-xl font-bold mb-4">Team Hustler</h4>
            <p>Join our team of hustlers, where your passion and drive fuel real change.</p>
          </div>
          <div className="bg-white p-8 shadow-lg rounded-lg">
            <h4 className="text-xl font-bold mb-4">Volunteers</h4>
            <p>Make a difference by volunteering with us, contributing your time and skills to support our mission.</p>
          </div>
          <div className="bg-white p-8 shadow-lg rounded-lg">
            <h4 className="text-xl font-bold mb-4">Mentor Network</h4>
            <p>Become a part of our mentors network, guiding and inspiring the next generation of innovators.</p>
          </div>
        </div>
      </div>

      <div className="bg-white py-20">
        <h2 className="text-4xl font-bold text-center mb-10">Intern Opportunities</h2>
        <div className="flex justify-around items-center px-20">
          <div className="bg-purple-700 text-white p-8 rounded-lg shadow-lg">
            <h4 className="text-xl font-bold mb-4">Copywriter</h4>
            <p>Get involved in creating impactful content.</p>
          </div>
          <div className="bg-yellow-500 text-white p-8 rounded-lg shadow-lg">
            <h4 className="text-xl font-bold mb-4">Event Manager</h4>
            <p>Lead and organize major campus events.</p>
          </div>
          <div className="bg-red-600 text-white p-8 rounded-lg shadow-lg">
            <h4 className="text-xl font-bold mb-4">Executive Manager</h4>
            <p>Drive strategic initiatives and growth.</p>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 py-20 text-center">
        <h2 className="text-4xl font-bold mb-6">Perks and Benefits</h2>
        <p className="text-xl mx-auto max-w-4xl">
          At TBI-GEU, we offer a range of perks and benefits to support your personal and professional growth. Enjoy the flexibility to work from anywhere, access continuous learning opportunities, and gain hands-on experience in a dynamic environment.
        </p>
      </div>

      <div className="bg-white py-20 text-center">
        <h2 className="text-4xl font-bold mb-6">Internship Calendar</h2>
        <div className="flex justify-around">
          <div className="bg-orange-500 text-white py-4 px-8 rounded-lg shadow-lg">
            <h4 className="text-xl font-bold mb-4">Spring Internship</h4>
            <p>15 March to 15 May</p>
          </div>
          <div className="bg-orange-600 text-white py-4 px-8 rounded-lg shadow-lg">
            <h4 className="text-xl font-bold mb-4">Summer Internship</h4>
            <p>15 July to 15 Sept</p>
          </div>
          <div className="bg-orange-700 text-white py-4 px-8 rounded-lg shadow-lg">
            <h4 className="text-xl font-bold mb-4">Winter Internship</h4>
            <p>15 Nov to 15 Jan</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BodyContent;
