import React, { useState } from 'react';

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <nav className="bg-white shadow-md">
            <div className="container mx-auto px-4 flex justify-between items-center h-16">
                <div className="flex items-center space-x-4">
                    <img src="/logo.png" alt="TBI Logo" className="h-10 w-10"/>
                </div>
                <div className="md:hidden">
                    <button onClick={() => setIsOpen(!isOpen)} type="button" className="text-gray-800 hover:text-gray-600 focus:outline-none focus:text-gray-600">
                        <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
                            <path fillRule="evenodd" d="M4 5h16a1 1 0 010 2H4a1 1 0 110-2zm0 6h16a1 1 0 010 2H4a1 1 0 010-2zm0 6h16a1 1 0 010 2H4a1 1 0 110-2z"/>
                        </svg>
                    </button>
                </div>
                <ul className={`md:flex items-center space-x-6 ${isOpen ? 'flex flex-col absolute bg-white w-full left-0 top-16' : 'hidden'}`}>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Home</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">About</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Events</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Skill Development</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Incubation</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Resources</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Community</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-blue-600">Summit One</a></li>
                </ul>

                <div className="flex items-center space-x-4">
                    <img src="/gehu.png" alt="Graphic Era Logo" className="h-10 w-10"/>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
