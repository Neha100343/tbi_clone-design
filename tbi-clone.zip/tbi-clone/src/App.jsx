import React from 'react';
import Header from './components/NavBar.jsx';
import BodyContent from './components/BodyContent.jsx';
import Footer from './components/Footer.jsx';


function App() {
  return (
    <div>
      <Header />
      <BodyContent />
      <Footer />
    </div>
  );
}

export default App;
